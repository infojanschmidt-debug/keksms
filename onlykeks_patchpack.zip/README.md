# ONLYKEKS — Post, die schmeckt.

## Live
- Homepage: https://infojanschmidt-debug.github.io/keksms/
- Konfigurator: https://infojanschmidt-debug.github.io/keksms/konfigurator.html
- Preview: https://infojanschmidt-debug.github.io/keksms/preview.html
- Hall/Share: https://infojanschmidt-debug.github.io/keksms/keks.html

## Struktur
- index.html = Landing
- konfigurator.html = Konfigurator (MVP)
- preview.html = Preview (reads localStorage)
- keks.html = Hall/Share/Reply (optional)
- assets/ = Bilder/3D/JS
- cookie3d.js = 3D/Logic (wenn vorhanden)

## Regel
ONLYKEKS erklärt nichts. ONLYKEKS schmeckt.
